import re
import asyncio
from guilded import Client, utils
from guilded.ext import commands
from googlesearch import search

# Replace with your actual Guilded bot token IMPORTANT
GUILDED_API_TOKEN = 'bot_token'

# Replace with your actual Server ID and Channel IDs
SERVER_ID = 'SERVER_ID' # put your server id here
COMMAND_CHANNEL_ID = '_general_server' # put the id of the channel where you want to filter, google and do math
BADWORD_CHANNEL_ID = 'Command_channel_id' # put the id of the channel you want to add bad words

# change "name" with the username on your computer !!dont change anything else or it wont work!!
BAD_WORDS_FILE = 'C:/Users/Name/Desktop/GUILDEDbot/bad_words.txt'

bot = commands.Bot(command_prefix="+")

bad_words = []

def load_bad_words():
    global bad_words
    try:
        with open(BAD_WORDS_FILE, 'r') as file:
            bad_words = [line.strip() for line in file.readlines() if line.strip()]
    except FileNotFoundError:
        print(f"Bad words file ({BAD_WORDS_FILE}) not found. Creating new file.")

def save_bad_words():
    try:
        with open(BAD_WORDS_FILE, 'w') as file:
            file.write('\n'.join(bad_words))
    except Exception as e:
        print(f"Error saving bad words to {BAD_WORDS_FILE}: {e}")

def filter_bad_words(message):
    for word in bad_words:
        message = re.sub(rf'\b{word}\b', '*' * len(word), message, flags=re.IGNORECASE)
    return message

@bot.event
async def on_ready():
    try:
        print(f'Bot is ready and logged in as {bot.user}')

        load_bad_words()

    except Exception as e:
        print(f"Error in on_ready: {e}")

@bot.command()
async def math(ctx, *, equation):
    """Perform mathematical calculations."""
    try:
        result = eval(equation)
        await ctx.send(f'{equation} = {result}')
    except Exception as e:
        await ctx.send(f'Error: {e}')

@bot.command()
async def google(ctx, *, query):
    """Search for information on Google."""
    try:
        await ctx.send(f'Google search result: https://www.google.com/search?q={query}')
    except Exception as e:
        await ctx.send(f'Error: {e}')

@bot.command(aliases=['abw'])
async def addbadword(ctx, *, word):
    """Add a bad word to filter (restricted to BADWORD_CHANNEL_ID)."""
    try:
        if ctx.channel.id != BADWORD_CHANNEL_ID:
            await ctx.send("You can only add bad words in the bad words channel.")
            return

        word = word.lower()
        if word not in bad_words:
            bad_words.append(word)
            save_bad_words()  
            await ctx.send(f'Added "{word}" to bad words list.')
        else:
            await ctx.send(f'"{word}" is already in bad words list.')
    except Exception as e:
        await ctx.send(f"Error adding bad word: {e}")

@bot.command(aliases=['rbw'])
async def removebadword(ctx, *, word):
    """Remove a bad word from filter (restricted to BADWORD_CHANNEL_ID)."""
    try:
        if ctx.channel.id != BADWORD_CHANNEL_ID:
            await ctx.send("You can only remove bad words in the bad words channel.")
            return

        word = word.lower()
        if word in bad_words:
            bad_words.remove(word)
            save_bad_words()  
            await ctx.send(f'Removed "{word}" from bad words list.')
        else:
            await ctx.send(f'"{word}" is not in bad words list.')
    except Exception as e:
        await ctx.send(f"Error removing bad word: {e}")

@bot.event
async def on_message(message):
    try:
        if message.author == bot.user:
            return

        if message.channel.id != BADWORD_CHANNEL_ID:
            filtered_content = filter_bad_words(message.content)
            if filtered_content != message.content:
                await message.delete()
                await message.channel.send(f'{message.author.mention}, watch your language!')
                print(f'Deleted message from {message.author.display_name}: {message.content}')
    except Exception as e:
        print(f"Error processing message: {e}")

    await bot.process_commands(message)

bot.run(GUILDED_API_TOKEN)




#__  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
#|  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
#| |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
#| |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
#|_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 