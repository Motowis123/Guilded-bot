Guilded bot
Has a few functions, reminder you dont have to type the <> in the guilded server
+math <problem> # only works with numbers
+google <text> # isnt very good and works best with one word
+addbadword or +abw <word, can use paces>
+removebadword or +rbw <your word, can use spaces>
Install pip if you havent by typing this in your cmd:
python get-pip.py
And intall guilded and google:
pip install guilded.py
pip install googlesearch-python
Requires Python, install python here: https://www.python.org/ftp/python/3.12.4/python-3.12.4-amd64.exe
PASTE LINK IN BROWSER TO GET RIGHT VERSION
DONT TAKE STUFF OUT OF THE GUILDEDbot FOLDER JUST DRAG IT TO THE DESKTOP AND THEN RIGHT-CLICK THE PY FILE AND EDIT IN THERE YOU CAN SEE THE STUFF YOU NEED TO EDIT ALSO DONT MESS WITH THE FILE PATH ONLY EDIT THE NAME TO YOUR NAME.

search up on youtube on how to make a bot
To get server and chanel ids you gotta turn on developer mode in settings, if you cant find it search it up on youtube or google. When turned on make a new server called something like Bad_words make it private and make the bot have full accsess to all of the options then right click it and hit copy channel id and paste it in the banword_channel_id then copy the id of your general server and put it in COMMAND_CHANNEL_ID it says general server where you should paste it and command_cahnnel_id where you sshould paste the other one. then right click the server click copy server id and paste the server id in the server_id section. Remember to also paste your bot token in the bot token section.

!Have fun and sorry for any spelling mistakes!


 __  __    _    ____  _____   ______   __  __  __  ___ _____ _____        _____ ____  _ ____  _____ 
 |  \/  |  / \  |  _ \| ____| | __ ) \ / / |  \/  |/ _ \_   _/ _ \ \      / /_ _/ ___|/ |___ \|___ / 
 | |\/| | / _ \ | | | |  _|   |  _ \\ V /  | |\/| | | | || || | | \ \ /\ / / | |\___ \| | __) | |_ \ 
 | |  | |/ ___ \| |_| | |___  | |_) || |   | |  | | |_| || || |_| |\ V  V /  | | ___) | |/ __/ ___) |
 |_|  |_/_/   \_\____/|_____| |____/ |_|   |_|  |_|\___/ |_| \___/  \_/\_/  |___|____/|_|_____|____/ 